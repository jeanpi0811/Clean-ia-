import { BadRequestException, Controller, Headers, Post, Req, Body, UseGuards, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';
import Stripe from 'stripe';
import { JwtGuard, CheckoutDto } from './auth';
import { PrismaService } from './prisma.service';
@Controller('billing')
export class BillingController {
 private stripe?:Stripe;
 constructor(private config:ConfigService,private db:PrismaService){ const key=config.get<string>('STRIPE_SECRET_KEY'); if(key)this.stripe=new Stripe(key); }
 @UseGuards(JwtGuard) @Post('checkout') async checkout(@Req() req:Request & {user:{id:string;email:string}},@Body() dto:CheckoutDto){
  if(!this.stripe)throw new ServiceUnavailableException('Stripe não configurado.');
  const priceKeys:Record<string,string>={monthly:'STRIPE_PRICE_PRO_MONTHLY',yearly:'STRIPE_PRICE_PRO_YEARLY',lifetime:'STRIPE_PRICE_LIFETIME'};
  const price=this.config.get<string>(priceKeys[dto.plan]);
  if(!price)throw new ServiceUnavailableException('Preço Stripe do plano não configurado.');
  const session=await this.stripe.checkout.sessions.create({mode:dto.plan==='lifetime'?'payment':'subscription',line_items:[{price,quantity:1}],success_url:`${this.config.get('APP_WEB_URL')}/billing/success?session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${this.config.get('APP_WEB_URL')}/billing/cancel`,client_reference_id:req.user.id,customer_email:req.user.email,metadata:{userId:req.user.id,plan:dto.plan}});
  return {url:session.url};
 }
 @Post('webhook') async webhook(@Req() req:Request & {rawBody?:Buffer},@Headers('stripe-signature') sig?:string){
  if(!this.stripe||!req.rawBody||!sig)throw new BadRequestException('Webhook indisponível ou assinatura ausente.');
  let event:Stripe.Event; try{event=this.stripe.webhooks.constructEvent(req.rawBody,sig,this.config.getOrThrow('STRIPE_WEBHOOK_SECRET'));}catch{throw new BadRequestException('Assinatura de webhook inválida.');}
  if(event.type==='checkout.session.completed'){
   const s=event.data.object as Stripe.Checkout.Session; const userId=s.metadata?.userId; const providerRef=s.subscription?.toString()??s.id;
   if(userId)await this.db.subscription.upsert({where:{providerRef},create:{userId,provider:'stripe',providerRef,plan:s.metadata?.plan??'unknown',status:'active'},update:{status:'active'}});
  }
  return {received:true};
 }
}
