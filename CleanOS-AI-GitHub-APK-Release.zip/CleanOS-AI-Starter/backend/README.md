# API CleanOS

NestJS + Prisma/PostgreSQL. A API guarda conta, dispositivos, eventos de sincronização, histórico de limpeza, relatórios semanais e referências de assinatura. Redis suporta health check e lock distribuído do job semanal.

Rotas: `GET /api/health`; `POST /api/auth/register|login|refresh|logout`; `GET/POST /api/devices`; `POST/GET /api/sync/events`; `POST/GET /api/cleanups`; `GET /api/reports`; `POST /api/billing/checkout`; `POST /api/billing/webhook`.

Configure `.env` a partir de `.env.example`; migrations Prisma ficam em `prisma/migrations`. Nunca confie no cliente para status premium; compras nativas precisam de validação server-side antes de conceder privilégios.
