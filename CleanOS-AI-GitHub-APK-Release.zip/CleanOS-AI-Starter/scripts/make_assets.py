#!/usr/bin/env python3
from pathlib import Path
import cairosvg
root=Path(__file__).resolve().parents[1]
for src,dst in [(root/'assets/cleanos-logo.svg',root/'assets/logo.png'),(root/'assets/cleanos-icon.svg',root/'frontend-mobile/assets/icon.png'),(root/'assets/cleanos-icon.svg',root/'frontend-mobile/assets/adaptive-icon.png')]:
 dst.parent.mkdir(parents=True,exist_ok=True)
 cairosvg.svg2png(url=str(src),write_to=str(dst),output_width=1024,output_height=1024)
# Splash is an original 1024x1024 brand mark centered on a solid dark canvas.
src=root/'assets/cleanos-icon.svg'; dst=root/'frontend-mobile/assets/splash.png'
cairosvg.svg2png(url=str(src),write_to=str(dst),output_width=1024,output_height=1024)
print('Generated 1024x1024 logo, app icon, adaptive icon and splash PNGs.')
