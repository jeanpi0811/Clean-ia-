export type DevicePlatform = 'windows' | 'android' | 'ios' | 'macos' | 'linux';
export interface HealthSnapshot {
  platform: DevicePlatform;
  capturedAt: string;
  cpuPercent: number | null;
  memoryPercent: number | null;
  diskTotalBytes: number | null;
  diskFreeBytes: number | null;
  batteryPercent: number | null;
  temperatureC: number | null;
  gpuPercent: number | null;
}
export type FindingKind = 'duplicate' | 'large' | 'blurry' | 'organizable' | 'unused-app';
export interface FileFinding {
  id: string;
  path: string;
  name: string;
  sizeBytes: number;
  kind: FindingKind;
  confidence?: number;
  suggestedPath?: string;
}
export interface CleanupRecord {
  id: string;
  createdAt: string;
  freedBytes: number;
  categories: string[];
  platform: DevicePlatform;
}
