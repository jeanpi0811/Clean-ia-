# Desktop

Electron + React/Vite com bridge `contextIsolation` e `nodeIntegration=false`. `npm run dev` compila main/preload, serve Vite e abre Electron. `npm run build` compila os bundles; empacote no runner da plataforma com `npm run package:linux`, `npm run package:windows` ou `npm run package:macos`.

A varredura é restrita à pasta escolhida, ignora symlinks e limita profundidade/quantidade. Exclusão é apenas de duplicatas exatas selecionadas e não segue links. Organização cria prévia por extensão e move apenas itens selecionados, sem sobrescrever arquivos. A análise de blur usa um ONNX fornecido pelo operador, com entrada RGB 224×224, NCHW e saída de probabilidade de duas classes (classe 1 = borrada); se ausente, é desativada. Não há similaridade semântica nem detector de apps usados neste starter.
