import type {IpcMain,Dialog} from 'electron';
import {app} from 'electron';
import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import si from 'systeminformation';
import sharp from 'sharp';
import * as ort from 'onnxruntime-node';
import {isWithin} from './path-safety';

type Finding={id:string;path:string;name:string;sizeBytes:number;kind:'duplicate'|'large'|'blurry'|'organizable';confidence?:number;suggestedPath?:string};
const modelPath=()=>process.env.AI_MODEL_PATH||path.resolve(app.getAppPath(),'../../ai-models/blur-classifier.onnx');
let session:ort.InferenceSession|undefined;
async function digest(file:string){return new Promise<string>((resolve,reject)=>{const h=crypto.createHash('sha256');createReadStream(file).on('data',chunk=>{h.update(chunk);}).on('error',reject).on('end',()=>resolve(h.digest('hex')));});}
async function blurScore(file:string){
 try{session??=await ort.InferenceSession.create(modelPath(),{executionProviders:['cpu']});const {data,info}=await sharp(file).resize(224,224,{fit:'cover'}).removeAlpha().raw().toBuffer({resolveWithObject:true});
 const input=new Float32Array(1*3*224*224);for(let i=0;i<224*224;i++){input[i]=(data[i*info.channels]??0)/255;input[224*224+i]=(data[i*info.channels+1]??0)/255;input[2*224*224+i]=(data[i*info.channels+2]??0)/255;}
 const name=session.inputNames[0];const out=await session.run({[name]:new ort.Tensor('float32',input,[1,3,224,224])});const vals=Object.values(out)[0].data as Float32Array;return vals.length>1?Number(vals[1]):Number(vals[0]);}catch{return null;}
}
export async function analyzeFolder(folder:string):Promise<Finding[]>{
 const root=path.resolve(folder);const st=await fs.stat(root);if(!st.isDirectory())throw new Error('Selecione uma pasta.');
 const files:string[]=[];const walk=async(dir:string,depth:number):Promise<void>=>{if(depth>12||files.length>=10000)return;for(const ent of await fs.readdir(dir,{withFileTypes:true})){if(ent.isSymbolicLink())continue;const p=path.join(dir,ent.name);if(ent.isDirectory())await walk(p,depth+1);else if(ent.isFile())files.push(p);}};await walk(root,0);
 const findings:Finding[]=[], hashes=new Map<string,string>();
 for(const file of files){try{const s=await fs.stat(file);if(!s.isFile())continue;const id=crypto.createHash('sha1').update(file).digest('hex');const name=path.basename(file);const ext=path.extname(name).slice(1).toLowerCase();
 if(s.size>=100*1024*1024)findings.push({id,path:file,name,sizeBytes:s.size,kind:'large'});
 if(['jpg','jpeg','png','webp','heic','tif','tiff'].includes(ext)){const key=`${s.size}:${await digest(file)}`;const original=hashes.get(key);if(original)findings.push({id,path:file,name,sizeBytes:s.size,kind:'duplicate'});else hashes.set(key,file);
 const score=await blurScore(file);if(score!==null&&score>0.65)findings.push({id,path:file,name,sizeBytes:s.size,kind:'blurry',confidence:Math.min(score,1)});}
 const dest=path.join(root,'Organizados',ext?`${ext.toUpperCase()}`:'Sem extensão',name);if(path.dirname(file)!==path.dirname(dest))findings.push({id,path:file,name,sizeBytes:s.size,kind:'organizable',suggestedPath:dest});
 }catch{/* arquivo inacessível é ignorado sem falhar o scan */}}
 return findings;
}
export function registerHandlers(ipc:IpcMain,dialog:Dialog){
 ipc.handle('choose-folder',async()=>{const r=await dialog.showOpenDialog({properties:['openDirectory']});return r.canceled?null:r.filePaths[0];});
 ipc.handle('health',async()=>{const [mem,load,battery,disks,temps,graphics]=await Promise.all([si.mem(),si.currentLoad(),si.battery(),si.fsSize(),si.cpuTemperature(),si.graphics()]);const disk=disks.sort((a,b)=>b.size-a.size)[0];return {platform:process.platform,capturedAt:new Date().toISOString(),cpuPercent:Number(load.currentLoad.toFixed(1)),memoryPercent:Number((mem.active/mem.total*100).toFixed(1)),diskTotalBytes:disk?.size??null,diskFreeBytes:disk?.available??null,batteryPercent:battery.hasBattery?battery.percent:null,temperatureC:temps.main>0?temps.main:null,gpuPercent:graphics.controllers.find(g=>g.utilizationGpu)?.utilizationGpu??null,hostname:os.hostname()};});
 ipc.handle('model-status',async()=>{try{await fs.access(modelPath());return 'Modelo ONNX encontrado; análise de blur habilitada.';}catch{return 'Modelo ONNX não instalado; análise de blur indisponível.';}});
 ipc.handle('analyze',async(_e,folder:string)=>analyzeFolder(folder));
 ipc.handle('organize',async(_e,folder:string,ids:string[])=>{const root=path.resolve(folder);const findings=await analyzeFolder(root);const selected=findings.filter(f=>f.kind==='organizable'&&ids.includes(f.id));const errors:string[]=[];let moved=0;for(const f of selected){if(!f.suggestedPath||!isWithin(root,f.path)||!isWithin(root,f.suggestedPath)){errors.push(`${f.name}: caminho recusado`);continue;}try{await fs.mkdir(path.dirname(f.suggestedPath),{recursive:true});let target=f.suggestedPath;try{await fs.access(target);target=target.replace(/(\.[^.]+)?$/,`-${Date.now()}$1`);}catch{}await fs.rename(f.path,target);moved++;}catch{errors.push(`${f.name}: não foi possível mover`);}}return {moved,errors};});
 ipc.handle('clean',async(_e,folder:string,ids:string[])=>{const root=path.resolve(folder);if(!Array.isArray(ids)||ids.length>1000)return {deleted:0,bytes:0};const findings=await analyzeFolder(root);const approved=findings.filter(f=>f.kind==='duplicate'&&ids.includes(f.id)&&isWithin(root,f.path));let deleted=0,bytes=0;for(const f of approved){try{const st=await fs.lstat(f.path);if(!st.isFile()||st.isSymbolicLink())continue;await fs.unlink(f.path);bytes+=st.size;deleted++;}catch{/* item já removido ou não acessível */}}return {deleted,bytes};});
}
