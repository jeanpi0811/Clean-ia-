import { app, BrowserWindow, ipcMain, dialog, shell } from 'electron';
import path from 'node:path';
import { registerHandlers } from './services';
const here=__dirname;
function createWindow(){
 const win=new BrowserWindow({width:1440,height:920,minWidth:1000,minHeight:700,backgroundColor:'#080d16',title:'CleanOS AI',webPreferences:{preload:path.join(here,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
 if(process.env.VITE_DEV_SERVER_URL)void win.loadURL(process.env.VITE_DEV_SERVER_URL);else void win.loadFile(path.join(here,'../renderer/index.html'));
 win.webContents.setWindowOpenHandler(({url})=>{if(url.startsWith('https:'))void shell.openExternal(url);return {action:'deny'};});
}
app.whenReady().then(()=>{registerHandlers(ipcMain,dialog);createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
